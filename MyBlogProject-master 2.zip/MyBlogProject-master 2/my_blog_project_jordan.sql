-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Client :  localhost:3306
-- Généré le :  Mer 14 Décembre 2016 à 19:39
-- Version du serveur :  5.6.33
-- Version de PHP :  7.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Base de données :  `my_blog_project`
--

-- --------------------------------------------------------

--
-- Structure de la table `articles`
--

CREATE TABLE `articles` (
  `id` int(11) UNSIGNED NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `category_id` int(11) UNSIGNED DEFAULT NULL,
  `status` tinyint(11) DEFAULT NULL,
  `chapeau` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `articles`
--

INSERT INTO `articles` (`id`, `title`, `content`, `user_id`, `created`, `updated`, `slug`, `category_id`, `status`, `chapeau`) VALUES
(5, 'DiplÃ´me - Bachelor de Chef de Projet (HÃ©tic)', ' Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 1, '2016-11-24 18:59:02', '2016-11-24 18:59:02', 'diplome_bachelor_de_chef_de_projet_hetic', 1, 1, 'jfiojsdoif sdfljdsfj pdosjf podsjfpods'),
(6, 'Eh coucouuuuu ! Un autre article !', 'foeisjf ois jfoisjdf osjpfosdpfjsdifjsdi fjdsoif joÃ¹dsjf Ã¹osdjfodisj foÃ¹isdj', 1, '2016-11-24 20:05:22', '2016-11-24 20:05:22', 'eh_coucouuuuu_un_autre_article', 1, 0, 'jfiojsdoif sdfljdsfj pdosjf podsjfpods'),
(7, 'Hello world', '<p>odfodsfods&nbsp;<strong>kfopdsk</strong>&nbsp;osdkf osdpfisdfomisfuisdf&nbsp;<em>dsfosdfidsfidsofi</em>&nbsp;dsf&nbsp;</p>', 1, '2016-12-04 17:12:39', '2016-12-04 17:12:39', 'hello_world', 1, 1, 'msdfjopsd jfposdfopsdfokdsof kdsfk p^dskfp ^dskpf kdskfjdsj hfudsfkjsdhfk qnd'),
(8, 'Encore un article ?', '<p>Maintenant il y a <strong>du bon gros gras</strong> mais aussi <em>du petit italique</em> !</p>\r\n<p>&nbsp;</p>\r\n<h1>Lorem Ipsum Lol</h1>\r\n<p style="text-align: center;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc fermentum leo vitae nulla mattis viverra. Aliquam scelerisque egestas massa ut cursus. Curabitur ullamcorper fringilla enim eu efficitur. Morbi posuere elit id fringilla rhoncus. Donec urna augue, pharetra nec scelerisque at, vestibulum eget justo. Integer fringilla vel lacus vitae rutrum. Nullam placerat accumsan ex, sodales posuere nunc consectetur non.</p>\r\n<h3>Lorem Ipsum Lol</h3>\r\n<p style="text-align: right;">Nulla egestas, nisi sit amet pharetra consequat, ipsum lectus commodo leo, vitae efficitur ipsum neque et nibh. Nullam non ante ex. Maecenas accumsan quam iaculis velit ornare, sed mollis tortor pretium. Pellentesque vulputate eros massa, quis mattis eros elementum vel. Sed facilisis venenatis purus vitae eleifend. Ut a erat maximus, luctus lacus et, commodo odio. Pellentesque commodo venenatis massa, nec dictum odio fermentum non. Duis eu lacinia quam.</p>\r\n<p>Nunc lorem odio, luctus in porttitor eu, vulputate at ligula. Donec tristique lobortis enim gravida accumsan. Nulla placerat diam quis urna bibendum, non viverra enim rutrum. In id tortor semper, luctus mi sit amet, mollis est. Curabitur eleifend ante vel sem vehicula pretium. Cras tempus neque id lorem aliquam, ut volutpat nibh porta. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aliquam eu scelerisque dui. Pellentesque sit amet gravida libero.</p>\r\n<ul>\r\n<li>lol</li>\r\n<li>mdr</li>\r\n<li>xptdr</li>\r\n</ul>\r\n<p><a title="Goooooogle !" href="http://google.fr">Nunc facilisis, est eget tempus volutpat, diam sapien mollis dui, ultricies tempus magna libero in sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam rhoncus aliquam sollicitudin. Pellentesque dolor dui, lobortis sed lobortis non, molestie iaculis quam. Etiam enim lectus, lacinia et interdum nec, congue at odio. Nunc nibh lacus, mattis sit amet magna vel, ultrices accumsan leo. Donec non egestas nunc. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Pellentesque non tincidunt lacus. Pellentesque eget nibh convallis, mollis felis sed, venenatis leo. Proin lobortis orci porttitor hendrerit pretium. Curabitur lobortis sit amet leo pharetra dignissim.</a></p>\r\n<p>Sed vel vulputate urna, sit amet suscipit erat. Nulla facilisi. Aliquam at dolor blandit augue accumsan posuere a ut velit. Nullam malesuada volutpat ante, a gravida purus commodo posuere. Nullam vitae dapibus dolor. Proin convallis scelerisque tellus quis imperdiet. Vestibulum ut pulvinar sem. In vitae nisl vel ante volutpat pulvinar et eget sapien.</p>', 1, '2016-12-04 20:09:07', '2016-12-04 20:09:07', 'encore_un_article', 1, 1, 'Et oui, Ã§a ne s\'arrÃªte pas dis donc !'),
(10, 're', '<p>blavlhfgd</p>', 2, '2016-12-14 15:29:16', '2016-12-14 15:29:16', 're', 1, 1, 'teste et reteste'),
(11, 're', '<p>blavlhfgd</p>', 2, '2016-12-14 15:29:29', '2016-12-14 15:29:29', 're', 1, 1, 'teste et reteste');

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) UNSIGNED NOT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `categories`
--

INSERT INTO `categories` (`id`, `title`) VALUES
(1, 'Par défaut');

-- --------------------------------------------------------

--
-- Structure de la table `commentaires`
--

CREATE TABLE `commentaires` (
  `id` int(11) UNSIGNED NOT NULL,
  `content` text,
  `date` datetime DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `article_id` int(11) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `commentaires`
--

INSERT INTO `commentaires` (`id`, `content`, `date`, `user_id`, `article_id`) VALUES
(1, 'dgjervjkdsnjb,djs glbfdnsfjkrngs', '2016-12-13 00:00:00', 1, 5),
(2, '<p>Bonjour</p>', '2016-12-14 14:12:37', 2, 8),
(3, '<p>Bonjour</p>', '2016-12-14 14:31:16', 0, 2),
(4, '<p>bonjour</p>', '2016-12-14 14:31:48', 2, 2),
(5, '<p>jordan is okkk ?</p>', '2016-12-14 14:48:51', 1, 2),
(6, '<p>jordan is okkk ?</p>', '2016-12-14 14:48:58', 1, 2),
(7, '<p>blabla</p>', '2016-12-14 15:29:42', 2, 9),
(8, '<p>blablaaaaaa</p>', '2016-12-14 15:30:07', 1, 9),
(9, '<p>JORDAN</p>', '2016-12-14 15:49:51', 1, 10),
(10, '<p>fhjgnfbfdjn</p>', '2016-12-14 15:51:57', 2, 11),
(11, '<p>fhjgnfbfdjn</p>', '2016-12-14 15:53:16', 2, 8);

-- --------------------------------------------------------

--
-- Structure de la table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `roles`
--

INSERT INTO `roles` (`id`, `name`) VALUES
(1, 'SUPER_ADMIN'),
(2, 'ADMIN'),
(3, 'BLOGGER'),
(4, 'MEMBER');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `role_id` int(11) UNSIGNED DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `role_id`, `created`, `updated`, `description`) VALUES
(1, 'txreplay', '95493ccf06c3a5eb9523816a80896d4e9121fef5', 'txreplay@gmail.com', 2, '2016-12-01 12:00:00', '2016-12-11 18:40:31', 'Cela fait quelque temps maintenant que je fais du dÃ©veloppement en JavaScript, et depuis peu, je donne aussi des cours de de ce langage Ã  des Ã©tudiants de 1Ã¨re annÃ©e.'),
(2, 'jordan77', 'e5b05bd9fe1be6ec96654ea6ece2aa7fac49c204', 'jordan.desjardin@gmail.com', 1, '2016-12-13 23:13:48', '2016-12-14 14:00:01', '');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Index pour la table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `commentaires`
--
ALTER TABLE `commentaires`
  ADD UNIQUE KEY `id` (`id`);

--
-- Index pour la table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_id` (`role_id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT pour la table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `commentaires`
--
ALTER TABLE `commentaires`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT pour la table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);
