<?php

require_once 'model/article.php';
require_once 'model/comment.php';

if($_POST['action']=='newcomment'){

	comment_save($_POST['content'], $_POST['date'], $user['id'], $_GET['id']);

    $message = [
        'type' => 'success',
        'title' => 'OK',
        'text' => 'Commentaire créé !'
    ];
}


$article = article_find_one_by('id', $_GET['id']);
$comments = comment_find_all_by('article_id', $_GET['id']);


if ($article === false) {
    $template = 'homepage';
} else {
    $template = 'article_single';
}