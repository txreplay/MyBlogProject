<?php

require_once 'model/comment.php';
$delete_comment = comment_remove($_GET['id']);

if ($delete_comment === true) {
    $message = [
        'type' => 'success',
        'title' => 'OK',
        'text' => 'Comment supprimé !'
    ];

    $template = 'article_single';
} else {
    $template = 'article_single';
}