<?php

require_once 'model/comment.php';

$update = check_update($comment); 

$id = $comment['id'];
$article = comment_find_one_by('id', $id);

if ($update === true) {
    $message = [
        'type' => 'success',
        'title' => 'OK',
        'text' => 'Commentaire modifié !'
    ];

    $template = 'article_show';
} else {
    $template = 'comment_edit';
}

function check_update($article)
{
    $errors = [];

    if(empty($_POST['content'])) {
        $errors['content'] = "Contenu du commentaire obligatoire";
    }

    $content_check = comment_find_one_by('content', $_POST['content']);


    return $errors;
}