<?php

require_once 'model/article.php';

$articles = article_find_all();