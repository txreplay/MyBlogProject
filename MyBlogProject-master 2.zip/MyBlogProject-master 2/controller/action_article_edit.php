<?php

require_once 'model/article.php';

$id = (key_exists('id', $_GET)) ? $_GET['id'] : $user['id'];
$article = article_find_one_by('id', $id);

if ($article === false) {
    $template = 'article_show';
} else {
    $template = 'article_edit';
}

function check_update($article)
{
    $errors = [];

    if(empty($_POST['title'])) {
        $errors['title'] = "Titre obligatoire";
    }

    $title_check = article_find_one_by('title', $_POST['title']);

    if(empty($_POST['chapeau'])) {
        $errors['chapeau'] = "Chapeau obligatoire";
    }


    $chapeau_check = article_find_one_by('chapeau', $_POST['chapeau']);

    if(empty($_POST['content'])) {
        $errors['content'] = "Contenu de l'article obligatoire";
    }

    $content_check = article_find_one_by('content', $_POST['content']);


    return $errors;
}