<?php

require_once 'model/comment.php';

$errors = check_save();

if (empty($errors)) {
    comment_save($_POST['content'], $_POST['date'], $user['id'], $article['id'];

    $message = [
        'type' => 'success',
        'title' => 'OK',
        'text' => 'Commentaire créé !'
    ];
    $template = 'homepage';
} else {
    $template = 'article_single';
}

function check_save()
{
    $errors = [];

    if(empty($_POST['content'])) {
        $errors['content'] = "Contenu obligatoire";
    }

    return $errors;
}