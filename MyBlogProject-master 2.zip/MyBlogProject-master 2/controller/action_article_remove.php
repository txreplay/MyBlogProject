<?php

require_once 'model/article.php';
$delete_article = article_remove($_GET['id']);

if ($delete_article === true) {
    $message = [
        'type' => 'success',
        'title' => 'OK',
        'text' => 'Article supprimé !'
    ];

    $template = 'profile_show';
} else {
    $template = 'profile_show';
}

