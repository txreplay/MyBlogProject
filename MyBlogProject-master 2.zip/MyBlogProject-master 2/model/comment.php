<?php

function comment_save($content, $user_id, $article_id)
{
    $query = 'INSERT INTO `commentaires` (`content`, `date`, `user_id`, `article_id`) VALUES (\''.my_escape($content).'\', \''.date("Y-m-d H:i:s").'\', \''.my_escape($user_id).'\', \''.my_escape($article_id).'\')';

    my_query($query);
}


function comment_update($content, $user_id, $article_id)
{
    $query = 'UPDATE `commentaires` SET content=\''.my_escape($content).'\', user_id=\''.my_escape($user_id).'\', date=\''.date("Y-m-d H:i:s").'\', article_id\''.my_escape($article_id).'\')';

    return my_query($query);
}

function comment_remove($id)
{
    $query = 'DELETE FROM `commentaires` WHERE id = $id';

    return my_query($query);
}


function comment_find_all_by($field, $value)
{
    $field = 'a.'.$field;

    $query = 'SELECT a.id as comment_id, a.content as comment_content, a.date as comment_date, u.id as user_id, o.id as article_id FROM `commentaires` AS a JOIN `users` as u ON a.user_id = u.id JOIN `articles` as o ON o.id = a.article_id WHERE '.$field.'=\''.my_escape($value).'\'';

    $result = my_fetch_all($query);

    if (is_null($result)) {
        $errors['comment'] = 'Ce commentaire n\'existe pas.';
        return false;
    } else {
        return $result;
    }
}

// function comment_find_all()
// {
//     $query = 'SELECT a.id as article_id, a.title as article_title, a.chapeau as article_chapeau, a.content as article_content, a.created as article_created, a.updated as article_updated, a.slug as article_slug, a.status as article_status, u.id as user_id, u.username as user_username FROM `articles` AS a JOIN `users` as u ON a.user_id = u.id WHERE a.status=\'1\' ORDER BY a.id DESC';

//     $result = my_fetch_all($query);

//     if (is_null($result)) {
//         $errors['articles'] = 'Erreur dans la récupération des articles.';
//         return false;
//     } else {
//         return $result;
//     }
// }