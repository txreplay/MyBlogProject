<article>
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1">
                <h2 class="section-heading"><?=$article['article_title']?></h2>
                <h4 class="subheading"><?=$article['article_chapeau']?></h4>
                <span class="meta">Posté par <a href="index.php?action=profile_show&id=<?=$article['user_id']?>"><?=$article['user_username']?></a> le  <?=$article['article_created']?></span>

                <p><?=$article['article_content']?></p>
            </div>

            <?php if (key_exists('user', $_SESSION)) { ?>

            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1">
                        <h2>Écrire un commentaire</h2>

                        <form action="" method="post">
                        <input type="hidden" name='action' value='newcomment'>
                            <div class="row control-group">
                                <div class="form-group col-xs-12 floating-label-form-group controls">
                                    <label for="content">Contenu du commentaire</label>
                                    <textarea name="content" class="form-control" cols="30" rows="10" id="content" placeholder="Contenu du commentaire"><?php if (isset($_POST['content'])) { echo $_POST['content']; } ?></textarea>
                                    </div>
                            </div>
                            <br>
                            <div id="success"></div>
                            <div class="row">
                                <div class="form-group col-xs-12">
                                    <input type="submit" class="btn btn-default" value="Poster">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php } ?>

<script>
    (function() {
        <?php
        if (isset($errors)) {
        foreach ($errors as $key => $error):
        ?>
        iziToast.error({
            title: 'Erreur',
            message: "<?php echo $error ?>",
            position: 'topRight',
            layout: 2,
            color: 'red',
            timeout: 10000
        });
        <?php
        endforeach;
        }
        ?>
    })();
</script>
<script src="bower_components/tinymce/tinymce.min.js"></script>
<script type="text/javascript">
    tinymce.init({
        selector: '#content',
        menubar: false,
        plugins: [
            'advlist autolink lists link image charmap print preview anchor',
            'searchreplace visualblocks code fullscreen',
            'insertdatetime media table contextmenu paste code'
        ],
        toolbar: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image'
    });
</script>
            <div class="container">
                <div class="row">

                    <?php
                        foreach ($comments as $comment) {
                            echo "<div class='com'>";
                            echo "<p>";
                            echo "<p>".$user['username']."&nbsp;";
                            echo $comment['comment_date']."</p>";
                            echo $comment['comment_content'];
                            echo "</p>"; 
                            echo "</div>";       
                        }

                        if (isset($user) && $profile['id'] === $user['id']) {

                    ?>

                        <a href="index.php?action=comment_edit&id=<?=$comment['comment_id']?>">Modifier</a>
                        <a href="index.php?action=comment_remove&id=<?=$comment['comment_id']?>">Supprimer</a> 

                    <?php } ?>

                </div>
            </div>
        </div>
    </div>
</article>

<script>
    (function() {
        iziToast.<?php echo $message['type'] ?>({
            title: "<?php echo $message['title'] ?>",
            message: "<?php echo $message['text'] ?>",
            position: 'topCenter',
            layout: 2,
            timeout: 5000
        });
    })();
</script>