<?php

global $salt, $action, $layout, $action_params;

$salt = '@8Ln*bBpU4Cd&o6QnJLeA%A$kG7BlW5*K@cgR-MRiTEmTe%D7)wogHt9GsAjy&Wl';
$action = 'homepage';
$layout = 'base';
$action_params = [];